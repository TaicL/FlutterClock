# Analog Clock

This app is an example of an analog clock.
It has a light theme and a dark theme, and displays sample weather and location data.

<img src='analog.gif' width='350'>

<img src='analog_dark.png' width='350'>

<img src='analog_light.png' width='350'>
